# ROSE AI ProGuard rules.
# Minification is off for debug builds; keep these rules for future release builds.

# Keep OkHttp platform references quiet.
-dontwarn okhttp3.**
-dontwarn okio.**

# Keep Compose-generated code paths intact.
-keep class androidx.compose.** { *; }
