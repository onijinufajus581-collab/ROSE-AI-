package com.roseai.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.roseai.app.ui.components.AICharacter
import com.roseai.app.ui.components.AnimatedButton
import com.roseai.app.ui.components.GlassCard
import com.roseai.app.ui.components.VoiceWaveform
import com.roseai.app.ui.theme.RoseColors
import com.roseai.app.viewmodel.RoseViewModel
import com.roseai.app.viewmodel.VoiceState

@Composable
fun VoiceScreen(vm: RoseViewModel, onBack: () -> Unit) {
    val state by vm.voiceState.collectAsState()
    val status by vm.status.collectAsState()
    val ttsStatus by vm.ttsStatus.collectAsState()
    val messages by vm.messages.collectAsState()
    val context = LocalContext.current

    val lastReply = messages.lastOrNull { it.role == "assistant" }?.text
    val active = state != VoiceState.IDLE

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.startVoice()
        else vm.setStatus("মাইক্রোফোন অনুমতি ছাড়া ভয়েস মোড চালু করা যাবে না।")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(RoseColors.Background, Color(0xFF1A0B2E))))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← BACK", color = RoseColors.Cyan) }
            Text("VOICE MODE", color = RoseColors.Cyan, fontWeight = FontWeight.ExtraBold)
        }

        AICharacter()

        Text(
            text = stateLabel(state),
            color = RoseColors.Pink,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )

        VoiceWaveform(active = state == VoiceState.LISTENING || state == VoiceState.SPEAKING)

        if (state == VoiceState.THINKING) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.height(22.dp), color = RoseColors.Cyan, strokeWidth = 2.dp)
                Text("  ভাবছি...", color = RoseColors.TextSecondary)
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text(lastReply ?: "আপনার সাথে কথা বলতে START চাপুন।", color = RoseColors.TextPrimary)
        }

        Text(ttsStatus, color = RoseColors.TextSecondary, fontSize = 12.sp)

        status?.let { message ->
            GlassCard(Modifier.fillMaxWidth()) {
                Text(message, color = RoseColors.Pink, fontSize = 13.sp)
            }
        }

        if (active) {
            AnimatedButton("STOP VOICE", Modifier.fillMaxWidth(), onClick = { vm.stopVoice() })
        } else {
            AnimatedButton(
                "START VOICE",
                Modifier.fillMaxWidth(),
                onClick = {
                    val granted = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    if (granted) vm.startVoice()
                    else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            )
        }

        Box(Modifier.height(8.dp))
    }
}

private fun stateLabel(state: VoiceState): String = when (state) {
    VoiceState.IDLE -> "প্রস্তুত — START চাপুন"
    VoiceState.LISTENING -> "🎧 শুনছি..."
    VoiceState.THINKING -> "🧠 ভাবছি..."
    VoiceState.SPEAKING -> "🔊 কথা বলছি..."
}
