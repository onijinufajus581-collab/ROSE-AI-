package com.roseai.app.ui.theme

import androidx.compose.material3.Typography

val RoseTypography = Typography()
