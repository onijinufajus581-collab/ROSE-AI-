package com.roseai.app.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Bengali text-to-speech. Uses a female voice only when the device engine provides one.
 * [onStatus] reports voice availability to the UI.
 */
class TTSManager(context: Context, private val onStatus: (String) -> Unit) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            val engine = tts
            if (status == TextToSpeech.SUCCESS && engine != null) {
                setup(engine)
            } else {
                ready = false
                onStatus("Text-to-Speech চালু করা যায়নি।")
            }
        }
    }

    private fun setup(engine: TextToSpeech) {
        val language = listOf(Locale("bn", "BD"), Locale("bn", "IN"), Locale("bn"))
            .firstOrNull { engine.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE }

        if (language == null) {
            ready = false
            onStatus("Bengali voice পাওয়া যায়নি। Android TTS settings-এ Bengali voice data ইনস্টল করুন।")
            return
        }

        engine.language = language
        val bengaliVoices = engine.voices?.filter { it.locale.language == "bn" }.orEmpty()
        val female = bengaliVoices.firstOrNull { it.name.contains("female", ignoreCase = true) }
        if (female != null) {
            engine.voice = female
            onStatus("Bengali female voice প্রস্তুত।")
        } else {
            onStatus("Bengali voice প্রস্তুত। (ডিভাইসে female voice না থাকলে ডিফল্ট voice ব্যবহার হবে।)")
        }
        ready = true
    }

    /** Speaks [text]. [finished] runs on the main thread when speech ends or cannot start. */
    fun speak(text: String, finished: () -> Unit) {
        val engine = tts
        if (!ready || engine == null) {
            finished()
            return
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { main.post { finished() } }
            override fun onError(utteranceId: String?) { main.post { finished() } }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rose-${System.nanoTime()}")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }
}
