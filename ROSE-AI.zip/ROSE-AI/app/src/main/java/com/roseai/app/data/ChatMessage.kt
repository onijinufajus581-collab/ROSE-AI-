package com.roseai.app.data

data class ChatMessage(
    val role: String,
    val text: String,
    val id: Long = System.nanoTime()
) {
    companion object {
        const val ROLE_USER = "user"
        const val ROLE_ASSISTANT = "assistant"
    }
}

data class ChatSession(val title: String, val messages: List<ChatMessage>)
