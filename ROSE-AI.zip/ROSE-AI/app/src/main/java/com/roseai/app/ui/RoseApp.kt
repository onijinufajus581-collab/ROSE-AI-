package com.roseai.app.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.roseai.app.ui.screens.ApiSettingsScreen
import com.roseai.app.ui.screens.ChatScreen
import com.roseai.app.ui.screens.HistoryScreen
import com.roseai.app.ui.screens.HomeScreen
import com.roseai.app.ui.screens.SettingsScreen
import com.roseai.app.ui.screens.SplashScreen
import com.roseai.app.ui.screens.VoiceScreen
import com.roseai.app.viewmodel.RoseViewModel

@Composable
fun RoseApp(vm: RoseViewModel) {
    val nav = rememberNavController()
    val animations by vm.animationsEnabled.collectAsState()

    NavHost(
        navController = nav,
        startDestination = "splash",
        enterTransition = { fadeIn(tween(400)) + slideInHorizontally(tween(400)) { it / 8 } },
        exitTransition = { fadeOut(tween(300)) },
        popEnterTransition = { fadeIn(tween(300)) },
        popExitTransition = { fadeOut(tween(300)) + slideOutHorizontally(tween(300)) { it / 8 } }
    ) {
        composable("splash") {
            SplashScreen(animationsEnabled = animations) {
                nav.navigate("home") { popUpTo("splash") { inclusive = true } }
            }
        }
        composable("home") {
            HomeScreen(
                vm = vm,
                onChat = { nav.navigate("chat") },
                onVoice = { nav.navigate("voice") },
                onNewChat = {
                    vm.newChat()
                    nav.navigate("chat")
                },
                onHistory = { nav.navigate("history") },
                onSettings = { nav.navigate("settings") },
                onApi = { nav.navigate("api") }
            )
        }
        composable("chat") {
            ChatScreen(vm = vm, onBack = { nav.popBackStack() })
        }
        composable("voice") {
            VoiceScreen(vm = vm, onBack = {
                vm.stopVoice()
                nav.popBackStack()
            })
        }
        composable("history") {
            HistoryScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onOpened = {
                    nav.popBackStack()
                    nav.navigate("chat")
                }
            )
        }
        composable("settings") {
            SettingsScreen(vm = vm, onBack = { nav.popBackStack() }, onApi = { nav.navigate("api") })
        }
        composable("api") {
            ApiSettingsScreen(vm = vm, onBack = { nav.popBackStack() })
        }
    }
}
