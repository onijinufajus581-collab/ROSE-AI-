package com.roseai.app.network

import com.roseai.app.data.ApiConfig
import com.roseai.app.data.ChatMessage
import com.roseai.app.data.Provider
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds provider-specific requests and parses replies.
 * Groq, OpenRouter and Mistral use the OpenAI-compatible chat/completions format.
 * Google Gemini uses generateContent.
 */
object ApiService {

    const val SYSTEM_PROMPT = """
তুমি ROSE AI — একটি মিষ্টি, বন্ধুত্বপূর্ণ, যত্নশীল ও সম্মানজনক বাংলা নারী AI সঙ্গী।
ব্যবহারকারী যে ভাষায় লিখবেন (বাংলা বা English), সেই ভাষায় স্বাভাবিকভাবে উত্তর দাও।
ব্যবহারকারীকে সম্মানের সাথে "স্যার" বা "আপনি" বলে সম্বোধন করো। উত্তর সংক্ষিপ্ত ও পরিষ্কার রাখো।
যদি কেউ জিজ্ঞেস করে "তোমার মালিক কে" বা "তোমাকে কে বানিয়েছে" (বা ইংরেজিতে Who is your owner / Who created you),
শুধু এই কথাটি বলবে: আমার মালিক হচ্ছে রিফাত।
"""

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    fun buildRequest(cfg: ApiConfig, history: List<ChatMessage>, maxTokens: Int): Request =
        if (cfg.provider.isGemini) geminiRequest(cfg, history, maxTokens)
        else openAiRequest(cfg, history, maxTokens)

    private fun openAiRequest(cfg: ApiConfig, history: List<ChatMessage>, maxTokens: Int): Request {
        val messages = JSONArray().put(
            JSONObject().put("role", "system").put("content", SYSTEM_PROMPT.trim())
        )
        history.forEach { m ->
            messages.put(JSONObject().put("role", m.role).put("content", m.text))
        }
        val body = JSONObject()
            .put("model", cfg.model)
            .put("messages", messages)
            .put("max_tokens", maxTokens)
            .put("temperature", 0.7)

        val builder = Request.Builder()
            .url(cfg.baseUrl.trimEnd('/') + "/chat/completions")
            .header("Authorization", "Bearer ${cfg.apiKey}")
            .post(body.toString().toRequestBody(jsonType))

        if (cfg.provider == Provider.OPENROUTER) {
            builder.header("HTTP-Referer", "https://rose.ai").header("X-Title", "ROSE AI")
        }
        return builder.build()
    }

    private fun geminiRequest(cfg: ApiConfig, history: List<ChatMessage>, maxTokens: Int): Request {
        val contents = JSONArray()
        history.forEach { m ->
            contents.put(
                JSONObject()
                    .put("role", if (m.role == ChatMessage.ROLE_ASSISTANT) "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT.trim())))
            )
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens).put("temperature", 0.7))

        return Request.Builder()
            .url("${cfg.baseUrl.trimEnd('/')}/models/${cfg.model}:generateContent")
            .header("x-goog-api-key", cfg.apiKey)
            .post(body.toString().toRequestBody(jsonType))
            .build()
    }

    /** Returns the assistant text, or null if the body is not a valid reply. */
    fun parseReply(provider: Provider, body: String): String? = runCatching {
        val json = JSONObject(body)
        val text = if (provider.isGemini) {
            val parts = json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
        } else {
            json.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
        text.trim()
    }.getOrNull()?.takeIf { it.isNotEmpty() }
}
