package com.roseai.app

import android.app.Application

class RoseApplication : Application()
