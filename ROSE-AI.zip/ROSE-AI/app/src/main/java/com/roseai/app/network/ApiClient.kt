package com.roseai.app.network

import com.roseai.app.data.ApiConfig
import com.roseai.app.data.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.IOException
import java.util.concurrent.TimeUnit

class AiException(message: String) : Exception(message)

data class TestResult(val ok: Boolean, val message: String, val reply: String? = null)

/**
 * Sends real HTTP requests. Success is returned only when a valid AI reply is parsed.
 * Keys are never logged and never included in error messages.
 */
object ApiClient {

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun chat(cfg: ApiConfig, history: List<ChatMessage>): String =
        withContext(Dispatchers.IO) { execute(cfg, history, maxTokens = 1024) }

    /** Lightweight real request used by the TEST button. */
    suspend fun test(cfg: ApiConfig): TestResult = withContext(Dispatchers.IO) {
        try {
            val reply = execute(
                cfg,
                listOf(ChatMessage(ChatMessage.ROLE_USER, "Reply with exactly one word: OK")),
                maxTokens = 16
            )
            TestResult(ok = true, message = "সংযোগ সফল", reply = reply.take(120))
        } catch (e: AiException) {
            TestResult(ok = false, message = e.message ?: "অজানা ত্রুটি")
        }
    }

    private fun execute(cfg: ApiConfig, history: List<ChatMessage>, maxTokens: Int): String {
        if (cfg.apiKey.isBlank()) throw AiException("API key খালি। একটি key লিখুন।")
        if (cfg.model.isBlank()) throw AiException("Model ID খালি। একটি model লিখুন।")

        val request = ApiService.buildRequest(cfg, history, maxTokens)
        val response = try {
            http.newCall(request).execute()
        } catch (e: IOException) {
            throw AiException("Network error: ইন্টারনেট সংযোগ বা Base URL চেক করুন।")
        }

        response.use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw AiException(httpError(r.code))
            return ApiService.parseReply(cfg.provider, body)
                ?: throw AiException("Server থেকে বৈধ AI উত্তর পাওয়া যায়নি।")
        }
    }

    private fun httpError(code: Int): String = when (code) {
        401, 403 -> "Unauthorized: API key ভুল বা অনুমতি নেই। (HTTP $code)"
        404 -> "Invalid model বা endpoint পাওয়া যায়নি। Model ID ও Base URL চেক করুন। (HTTP 404)"
        429 -> "Rate limit exceeded: কিছুক্ষণ পর আবার চেষ্টা করুন। (HTTP 429)"
        in 500..599 -> "Server error। পরে চেষ্টা করুন। (HTTP $code)"
        else -> "API error (HTTP $code)"
    }
}
