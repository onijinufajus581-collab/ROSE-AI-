package com.roseai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.roseai.app.ui.RoseApp
import com.roseai.app.ui.theme.RoseTheme
import com.roseai.app.viewmodel.RoseViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: RoseViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RoseTheme {
                RoseApp(viewModel)
            }
        }
    }
}
