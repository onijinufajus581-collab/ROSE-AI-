package com.roseai.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.roseai.app.ui.theme.RoseColors

/** Neon gradient button with a press-scale animation and a loading state. */
@Composable
fun AnimatedButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(if (pressed) 0.95f else 1f, label = "pressScale")
    val active = enabled && !loading
    val brush = if (active) {
        Brush.horizontalGradient(listOf(RoseColors.NeonBlue, RoseColors.Purple, RoseColors.Pink))
    } else {
        Brush.horizontalGradient(listOf(Color(0xFF2A2F45), Color(0xFF2A2F45)))
    }
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .shadow(if (active) 14.dp else 0.dp, RoundedCornerShape(16.dp), spotColor = RoseColors.Pink)
            .clip(RoundedCornerShape(16.dp))
            .background(brush)
            .clickable(interactionSource = interaction, indication = null, enabled = active, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
        } else {
            Text(text, color = if (active) Color.White else RoseColors.TextSecondary, fontWeight = FontWeight.Bold)
        }
    }
}
