package com.roseai.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.roseai.app.data.ApiConfig
import com.roseai.app.data.ChatMessage
import com.roseai.app.data.ChatRepository
import com.roseai.app.data.ChatSession
import com.roseai.app.data.Provider
import com.roseai.app.network.AiException
import com.roseai.app.network.ApiClient
import com.roseai.app.network.TestResult
import com.roseai.app.security.SecureStorage
import com.roseai.app.util.OwnerRule
import com.roseai.app.voice.SpeechManager
import com.roseai.app.voice.TTSManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING }

class RoseViewModel(application: Application) : AndroidViewModel(application) {

    private val secure = SecureStorage(application)
    private val repo = ChatRepository(application)

    val messages = MutableStateFlow(repo.loadCurrent())
    val archive = MutableStateFlow(repo.loadArchive())
    val isTyping = MutableStateFlow(false)
    val status = MutableStateFlow<String?>(null)
    val connectionLabel = MutableStateFlow(computeConnectionLabel())
    val voiceState = MutableStateFlow(VoiceState.IDLE)
    val ttsStatus = MutableStateFlow("ভয়েস ইঞ্জিন প্রস্তুত হচ্ছে...")
    val animationsEnabled = MutableStateFlow(repo.animationsEnabled)

    private val speech = SpeechManager(application)
    private val tts = TTSManager(application) { ttsStatus.value = it }
    private var voiceActive = false

    // ---------- API connection ----------

    fun savedConfig(provider: Provider): ApiConfig = secure.config(provider)

    fun activeProvider(): Provider? = secure.activeProvider()

    suspend fun testApi(cfg: ApiConfig): TestResult = ApiClient.test(cfg)

    fun connectAndSave(cfg: ApiConfig) {
        secure.save(cfg)
        refreshConnection()
        setStatus("✓ ${cfg.provider.label} সংযুক্ত ও সেভ হয়েছে।")
    }

    fun clearApi(provider: Provider) {
        secure.clear(provider)
        refreshConnection()
        setStatus("${provider.label} API মুছে ফেলা হয়েছে।")
    }

    fun refreshConnection() {
        connectionLabel.value = computeConnectionLabel()
    }

    private fun computeConnectionLabel(): String {
        val cfg = secure.activeConfig() ?: return "API সংযুক্ত নয় — Settings থেকে যোগ করুন"
        return "${cfg.provider.label} · ${cfg.model} · সংযুক্ত ✓"
    }

    fun setStatus(message: String?) {
        status.value = message
    }

    fun setAnimations(enabled: Boolean) {
        animationsEnabled.value = enabled
        repo.animationsEnabled = enabled
    }

    // ---------- Chat ----------

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || isTyping.value) return
        viewModelScope.launch { handleUserText(text, speak = false) }
    }

    fun retry() {
        if (isTyping.value) return
        var list = messages.value
        if (list.lastOrNull()?.role == ChatMessage.ROLE_ASSISTANT) list = list.dropLast(1)
        if (list.lastOrNull()?.role != ChatMessage.ROLE_USER) return
        messages.value = list
        repo.saveCurrent(list)
        viewModelScope.launch { respondTo(list, speak = false) }
    }

    fun newChat() {
        archiveCurrent()
        messages.value = emptyList()
        repo.saveCurrent(emptyList())
    }

    fun openSession(index: Int) {
        val session = archive.value.getOrNull(index) ?: return
        archive.value = archive.value - session
        archiveCurrent()
        messages.value = session.messages
        repo.saveCurrent(session.messages)
        repo.saveArchive(archive.value)
    }

    fun clearHistory() {
        messages.value = emptyList()
        archive.value = emptyList()
        repo.saveCurrent(emptyList())
        repo.saveArchive(emptyList())
        setStatus("Chat history মুছে ফেলা হয়েছে।")
    }

    private fun archiveCurrent() {
        val current = messages.value
        if (current.isEmpty()) return
        val title = current.firstOrNull { it.role == ChatMessage.ROLE_USER }?.text?.take(40) ?: "Chat"
        archive.value = (listOf(ChatSession(title, current)) + archive.value).take(30)
        repo.saveArchive(archive.value)
    }

    private suspend fun handleUserText(text: String, speak: Boolean) {
        val base = messages.value + ChatMessage(ChatMessage.ROLE_USER, text)
        messages.value = base
        repo.saveCurrent(base)
        respondTo(base, speak)
    }

    private suspend fun respondTo(list: List<ChatMessage>, speak: Boolean) {
        val lastUserText = list.last { it.role == ChatMessage.ROLE_USER }.text
        val reply = OwnerRule.answer(lastUserText) ?: fetchReply(list)

        if (reply != null) {
            val updated = list + ChatMessage(ChatMessage.ROLE_ASSISTANT, reply)
            messages.value = updated
            repo.saveCurrent(updated)
        }

        if (speak && voiceActive) {
            if (reply != null) {
                voiceState.value = VoiceState.SPEAKING
                tts.speak(reply) { afterSpeaking() }
            } else {
                listen()
            }
        }
    }

    private suspend fun fetchReply(list: List<ChatMessage>): String? {
        val cfg = secure.activeConfig()
        if (cfg == null) {
            setStatus("আগে Settings → API থেকে একটি API সংযুক্ত করুন।")
            return null
        }
        isTyping.value = true
        return try {
            ApiClient.chat(cfg, list.takeLast(20))
        } catch (e: AiException) {
            setStatus(e.message)
            null
        } finally {
            isTyping.value = false
        }
    }

    // ---------- Voice ----------

    fun startVoice() {
        if (!speech.isAvailable()) {
            setStatus("এই ডিভাইসে speech recognition পাওয়া যায়নি।")
            return
        }
        if (secure.activeConfig() == null) {
            setStatus("ভয়েস মোডের আগে API সংযুক্ত করুন।")
            return
        }
        voiceActive = true
        listen()
    }

    fun stopVoice() {
        voiceActive = false
        speech.stop()
        tts.stop()
        voiceState.value = VoiceState.IDLE
    }

    fun speakTest() {
        tts.speak("আমি রোজ এআই। আমার কণ্ঠ কি শুনতে পাচ্ছেন?") {}
    }

    private fun afterSpeaking() {
        if (voiceActive) listen() else voiceState.value = VoiceState.IDLE
    }

    private fun listen() {
        if (!voiceActive) return
        voiceState.value = VoiceState.LISTENING
        speech.listen(
            onRecognized = { text ->
                voiceState.value = VoiceState.THINKING
                viewModelScope.launch { handleUserText(text, speak = true) }
            },
            onFailed = { code ->
                if (voiceActive && SpeechManager.isRetryable(code)) {
                    listen()
                } else {
                    voiceActive = false
                    voiceState.value = VoiceState.IDLE
                    setStatus(SpeechManager.describe(code))
                }
            }
        )
    }

    override fun onCleared() {
        speech.release()
        tts.shutdown()
        super.onCleared()
    }
}
