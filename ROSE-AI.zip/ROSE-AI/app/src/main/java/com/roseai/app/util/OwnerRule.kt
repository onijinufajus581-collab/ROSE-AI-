package com.roseai.app.util

/**
 * Local fallback for the owner-identity rule. The same rule is in the AI
 * system prompt; this guarantees the answer even if the API misbehaves.
 */
object OwnerRule {
    const val ANSWER = "আমার মালিক হচ্ছে রিফাত।"

    private val triggers = listOf(
        "তোমার মালিক কে",
        "তোমাকে কে বানিয়েছে",
        "who is your owner",
        "who created you",
        "who made you",
        "who built you",
        "who owns you",
        "your owner"
    )

    fun answer(text: String): String? {
        val normalized = text.lowercase().replace("?", "").replace("।", "").trim()
        return if (triggers.any { normalized.contains(it) }) ANSWER else null
    }
}
