package com.roseai.app.data

enum class Provider(val label: String, val defaultBaseUrl: String, val defaultModel: String) {
    GROQ("Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
    OPENROUTER("OpenRouter", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct"),
    MISTRAL("Mistral", "https://api.mistral.ai/v1", "mistral-small-latest"),
    GEMINI("Google Gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.0-flash");

    val isGemini: Boolean get() = this == GEMINI
}

data class ApiConfig(
    val provider: Provider,
    val apiKey: String,
    val model: String,
    val baseUrl: String
) {
    val isUsable: Boolean get() = apiKey.isNotBlank() && model.isNotBlank()
}
