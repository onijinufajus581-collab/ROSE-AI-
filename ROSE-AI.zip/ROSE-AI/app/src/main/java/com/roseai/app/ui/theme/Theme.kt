package com.roseai.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RoseDarkScheme = darkColorScheme(
    primary = RoseColors.NeonBlue,
    secondary = RoseColors.Purple,
    tertiary = RoseColors.Pink,
    background = RoseColors.Background,
    surface = RoseColors.Surface,
    onPrimary = Color.Black,
    onBackground = RoseColors.TextPrimary,
    onSurface = RoseColors.TextPrimary,
    error = RoseColors.Error
)

@Composable
fun RoseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RoseDarkScheme,
        typography = RoseTypography,
        content = content
    )
}
