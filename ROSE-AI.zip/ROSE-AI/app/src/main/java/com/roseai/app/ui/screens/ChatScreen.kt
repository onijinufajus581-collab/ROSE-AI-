package com.roseai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.roseai.app.data.ChatMessage
import com.roseai.app.ui.components.AnimatedButton
import com.roseai.app.ui.components.ChatBubble
import com.roseai.app.ui.components.GlassCard
import com.roseai.app.ui.components.TypingIndicator
import com.roseai.app.ui.components.copyToClipboard
import com.roseai.app.ui.theme.RoseColors
import com.roseai.app.viewmodel.RoseViewModel

@Composable
fun ChatScreen(vm: RoseViewModel, onBack: () -> Unit) {
    val messages by vm.messages.collectAsState()
    val typing by vm.isTyping.collectAsState()
    val status by vm.status.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    LaunchedEffect(messages.size, typing) {
        val lastIndex = messages.size + (if (typing) 1 else 0) - 1
        if (lastIndex >= 0) listState.animateScrollToItem(lastIndex)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(RoseColors.Background, Color(0xFF12082A))))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onBack) { Text("← BACK", color = RoseColors.Cyan) }
            Text("ROSE AI", color = RoseColors.Cyan, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            TextButton(onClick = { vm.newChat() }) { Text("NEW CHAT", color = RoseColors.Pink) }
        }

        status?.let { message ->
            GlassCard(Modifier.fillMaxWidth().clickable { vm.setStatus(null) }) {
                Text(message, color = RoseColors.Pink, fontSize = 13.sp)
            }
            Box(Modifier.height(8.dp))
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Text(
                            "হ্যালো স্যার, আই এম রোজ এআই। আপনাকে কী সাহায্য করতে পারি?",
                            color = RoseColors.TextPrimary
                        )
                    }
                }
            }

            itemsIndexed(messages, key = { _, m -> m.id }) { index, message ->
                ChatBubble(
                    message = message,
                    isLastAssistant = message.role == ChatMessage.ROLE_ASSISTANT && index == messages.lastIndex,
                    onCopy = { copyToClipboard(context, message.text) },
                    onRetry = { vm.retry() }
                )
            }

            if (typing) {
                item {
                    GlassCard { TypingIndicator() }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("বাংলা বা English-এ লিখুন...") },
                maxLines = 4,
                shape = RoundedCornerShape(20.dp)
            )
            AnimatedButton(
                text = "SEND",
                enabled = input.isNotBlank() && !typing,
                onClick = {
                    vm.send(input)
                    input = ""
                }
            )
        }
    }
}

@Composable
fun HistoryScreen(vm: RoseViewModel, onBack: () -> Unit, onOpened: () -> Unit) {
    val sessions by vm.archive.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(RoseColors.Background, Color(0xFF12082A))))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← BACK", color = RoseColors.Cyan) }
            Text("CHAT HISTORY", color = RoseColors.Cyan, fontWeight = FontWeight.ExtraBold)
        }

        if (sessions.isEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("এখনো কোনো আগের chat নেই।", color = RoseColors.TextSecondary)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(sessions) { index, session ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(session.title, color = RoseColors.TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${session.messages.size} টি বার্তা",
                        color = RoseColors.TextSecondary,
                        fontSize = 12.sp
                    )
                    Box(Modifier.height(10.dp))
                    AnimatedButton("OPEN", onClick = {
                        vm.openSession(index)
                        onOpened()
                    })
                }
            }
        }

        AnimatedButton("CLEAR CHAT HISTORY", Modifier.fillMaxWidth(), onClick = { vm.clearHistory() })
    }
}
