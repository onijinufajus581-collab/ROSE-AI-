package com.roseai.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Stores chat history and UI preferences locally. Holds no secrets. */
class ChatRepository(context: Context) {

    private val prefs = context.getSharedPreferences("rose_local", Context.MODE_PRIVATE)

    fun loadCurrent(): List<ChatMessage> = readMessages(prefs.getString("current", null))

    fun saveCurrent(list: List<ChatMessage>) {
        prefs.edit().putString("current", writeMessages(list)).apply()
    }

    fun loadArchive(): List<ChatSession> {
        val raw = prefs.getString("archive", null) ?: return emptyList()
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ChatSession(o.getString("title"), readMessages(o.getString("messages")))
        }
    }

    fun saveArchive(list: List<ChatSession>) {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(JSONObject().put("title", s.title).put("messages", writeMessages(s.messages)))
        }
        prefs.edit().putString("archive", arr.toString()).apply()
    }

    var animationsEnabled: Boolean
        get() = prefs.getBoolean("animations", true)
        set(value) {
            prefs.edit().putBoolean("animations", value).apply()
        }

    private fun writeMessages(list: List<ChatMessage>): String {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("role", it.role).put("text", it.text)) }
        return arr.toString()
    }

    private fun readMessages(raw: String?): List<ChatMessage> {
        if (raw.isNullOrEmpty()) return emptyList()
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ChatMessage(o.getString("role"), o.getString("text"))
        }
    }
}
