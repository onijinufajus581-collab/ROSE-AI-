package com.roseai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import com.roseai.app.R
import com.roseai.app.data.ApiConfig
import com.roseai.app.data.Provider
import com.roseai.app.network.TestResult
import com.roseai.app.ui.components.AnimatedButton
import com.roseai.app.ui.components.FloatingParticles
import com.roseai.app.ui.components.GlassCard
import com.roseai.app.ui.theme.RoseColors
import com.roseai.app.viewmodel.RoseViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: RoseViewModel, onBack: () -> Unit, onApi: () -> Unit) {
    val connection by vm.connectionLabel.collectAsState()
    val animations by vm.animationsEnabled.collectAsState()
    val status by vm.status.collectAsState()
    val ttsStatus by vm.ttsStatus.collectAsState()

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(RoseColors.Background, Color(0xFF14082A))))
    ) {
        FloatingParticles(enabled = animations)

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← BACK", color = RoseColors.Cyan) }
                Text("SETTINGS", color = RoseColors.Cyan, fontWeight = FontWeight.ExtraBold)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.ic_launcher_foreground),
                    contentDescription = "ROSE AI logo",
                    modifier = Modifier.size(56.dp)
                )
                Text("  ROSE AI", color = RoseColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("API PROVIDER", color = RoseColors.TextSecondary, fontSize = 12.sp)
                Text(connection, color = RoseColors.Success, fontWeight = FontWeight.SemiBold)
                Box(Modifier.height(8.dp))
                AnimatedButton("🔑  API PROVIDER SETTINGS", Modifier.fillMaxWidth(), onClick = onApi)
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("VOICE / TEXT-TO-SPEECH", color = RoseColors.TextSecondary, fontSize = 12.sp)
                Text(ttsStatus, color = RoseColors.TextPrimary, fontSize = 13.sp)
                Box(Modifier.height(8.dp))
                AnimatedButton("🔊  TEST TEXT-TO-SPEECH", Modifier.fillMaxWidth(), onClick = { vm.speakTest() })
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ANIMATIONS", color = RoseColors.TextSecondary, fontSize = 12.sp)
                        Text(if (animations) "চালু" else "বন্ধ", color = RoseColors.TextPrimary)
                    }
                    Switch(checked = animations, onCheckedChange = { vm.setAnimations(it) })
                }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("DATA", color = RoseColors.TextSecondary, fontSize = 12.sp)
                Box(Modifier.height(8.dp))
                AnimatedButton("CLEAR CHAT HISTORY", Modifier.fillMaxWidth(), onClick = { vm.clearHistory() })
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("ABOUT ROSE AI", color = RoseColors.TextSecondary, fontSize = 12.sp)
                Text("ROSE AI v1.0.0", color = RoseColors.TextPrimary)
                Text("Owner: রিফাত", color = RoseColors.TextSecondary)
            }

            AnimatedButton(
                "SAVE SETTINGS",
                Modifier.fillMaxWidth(),
                onClick = { vm.setStatus("সেটিংস স্বয়ংক্রিয়ভাবে সেভ হয়।") }
            )

            status?.let { message ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(message, color = RoseColors.Pink, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun ApiSettingsScreen(vm: RoseViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val status by vm.status.collectAsState()

    var provider by remember { mutableStateOf(vm.activeProvider() ?: Provider.GROQ) }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<TestResult?>(null) }
    var testedSignature by remember { mutableStateOf<String?>(null) }

    // Load saved values whenever the provider tab changes.
    LaunchedEffect(provider) {
        val saved = vm.savedConfig(provider)
        apiKey = saved.apiKey
        model = saved.model
        baseUrl = saved.baseUrl
        testResult = null
        testedSignature = null
    }

    fun currentConfig() = ApiConfig(
        provider = provider,
        apiKey = apiKey.trim(),
        model = model.trim(),
        baseUrl = baseUrl.trim().ifEmpty { provider.defaultBaseUrl }
    )

    val signature = "${provider.name}|${apiKey.trim()}|${model.trim()}|${baseUrl.trim()}"
    val connectEnabled = testResult?.ok == true && testedSignature == signature

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(RoseColors.Background, Color(0xFF14082A))))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← BACK", color = RoseColors.Cyan) }
            Text("API PROVIDER", color = RoseColors.Cyan, fontWeight = FontWeight.ExtraBold)
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("PROVIDER", color = RoseColors.TextSecondary, fontSize = 12.sp)
            Box(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Provider.values().forEach { p ->
                    val selected = p == provider
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) Brush.horizontalGradient(listOf(RoseColors.NeonBlue, RoseColors.Pink))
                                else Brush.horizontalGradient(listOf(Color(0xFF1B1F38), Color(0xFF1B1F38)))
                            )
                            .clickable { provider = p }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(p.label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = apiKey,
                onValueChange = {
                    apiKey = it
                    testedSignature = null
                },
                label = { Text("API Key") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) "HIDE" else "SHOW", fontSize = 11.sp)
                    }
                }
            )
            Box(Modifier.height(8.dp))
            OutlinedTextField(
                value = model,
                onValueChange = {
                    model = it
                    testedSignature = null
                },
                label = { Text("Model ID") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Box(Modifier.height(8.dp))
            OutlinedTextField(
                value = baseUrl,
                onValueChange = {
                    baseUrl = it
                    testedSignature = null
                },
                label = { Text("Base URL (ফাঁকা রাখলে ডিফল্ট)") },
                placeholder = { Text(provider.defaultBaseUrl) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        AnimatedButton(
            text = "⚡ TEST API CONNECTION",
            modifier = Modifier.fillMaxWidth(),
            loading = testing,
            enabled = !testing,
            onClick = {
                val cfg = currentConfig()
                val sig = signature
                scope.launch {
                    testing = true
                    val result = vm.testApi(cfg)
                    testing = false
                    testResult = result
                    testedSignature = if (result.ok) sig else null
                }
            }
        )

        testResult?.let { r ->
            GlassCard(Modifier.fillMaxWidth()) {
                if (r.ok) {
                    Text("✓ API CONNECTION SUCCESSFUL", color = RoseColors.Success, fontWeight = FontWeight.ExtraBold)
                    Text("Provider: ${provider.label}", color = RoseColors.TextPrimary)
                    Text("Model: ${model.trim()}", color = RoseColors.TextPrimary)
                    Text("Connection status: Connected", color = RoseColors.TextPrimary)
                    Text("Test response: ${r.reply ?: ""}", color = RoseColors.TextPrimary)
                    Text("Test completed ✓", color = RoseColors.TextSecondary, fontSize = 12.sp)
                } else {
                    Text("✕ API CONNECTION FAILED", color = RoseColors.Error, fontWeight = FontWeight.ExtraBold)
                    Text(r.message, color = RoseColors.TextPrimary)
                }
            }
        }

        AnimatedButton(
            text = "CONNECT & SAVE API",
            modifier = Modifier.fillMaxWidth(),
            enabled = connectEnabled,
            onClick = { vm.connectAndSave(currentConfig()) }
        )

        AnimatedButton(
            text = "CLEAR API",
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                vm.clearApi(provider)
                apiKey = ""
                testResult = null
                testedSignature = null
            }
        )

        status?.let { message ->
            GlassCard(Modifier.fillMaxWidth()) {
                Text(message, color = RoseColors.Pink, fontSize = 13.sp)
            }
        }
    }
}
