package com.roseai.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.roseai.app.ui.theme.RoseColors
import kotlin.math.sin
import kotlin.random.Random

/** Three bouncing dots shown while the AI is typing. */
@Composable
fun TypingIndicator() {
    val transition = rememberInfiniteTransition(label = "typing")
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(3) { i ->
            val dotAlpha by transition.animateFloat(
                0.2f, 1f,
                infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse),
                label = "dot$i"
            )
            Box(
                Modifier
                    .size(9.dp)
                    .graphicsLayer { alpha = dotAlpha }
                    .clip(CircleShape)
                    .background(RoseColors.Cyan)
            )
        }
    }
}

/** Animated bars used as the voice waveform. */
@Composable
fun VoiceWaveform(active: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        0f, 6.2831f,
        infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "wavePhase"
    )
    Canvas(modifier.fillMaxWidth().height(80.dp)) {
        val bars = 32
        val slot = size.width / bars
        val barWidth = slot * 0.6f
        for (i in 0 until bars) {
            val amp = if (active) 0.25f + 0.75f * (0.5f + 0.5f * sin(phase + i * 0.4f)) else 0.08f
            val h = size.height * amp
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(RoseColors.Cyan, RoseColors.Pink)),
                topLeft = Offset(i * slot + (slot - barWidth) / 2, (size.height - h) / 2),
                size = Size(barWidth, h),
                cornerRadius = CornerRadius(barWidth / 2)
            )
        }
    }
}

private class Particle(
    val x0: Float,
    val y0: Float,
    val speed: Float,
    val radius: Float,
    val petal: Boolean,
    val color: Color
)

/** Floating rose petals and glowing particles behind screens. */
@Composable
fun FloatingParticles(modifier: Modifier = Modifier, enabled: Boolean = true) {
    val particles = remember {
        val random = Random(7)
        val palette = listOf(RoseColors.Cyan, RoseColors.NeonBlue, RoseColors.Pink, RoseColors.Purple)
        List(36) {
            Particle(
                x0 = random.nextFloat(),
                y0 = random.nextFloat(),
                speed = 0.3f + random.nextFloat() * 0.7f,
                radius = 3f + random.nextFloat() * 6f,
                petal = random.nextBoolean(),
                color = palette[random.nextInt(palette.size)]
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "particles")
    val t by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "particleTime"
    )
    Canvas(modifier = modifier.fillMaxSize()) {
        if (!enabled) return@Canvas
        particles.forEach { p ->
            val progress = (p.y0 + t * p.speed) % 1f
            val x = p.x0 * size.width + sin(t * 6.2831f * p.speed) * 24f
            val y = size.height * (1f - progress)
            if (p.petal) {
                drawOval(
                    color = p.color.copy(alpha = 0.6f),
                    topLeft = Offset(x, y),
                    size = Size(p.radius * 1.6f, p.radius)
                )
            } else {
                drawCircle(color = p.color.copy(alpha = 0.5f), radius = p.radius, center = Offset(x, y))
            }
        }
    }
}
