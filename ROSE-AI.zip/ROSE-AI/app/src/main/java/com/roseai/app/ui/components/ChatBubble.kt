package com.roseai.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.roseai.app.data.ChatMessage
import com.roseai.app.ui.theme.RoseColors

@Composable
fun ChatBubble(
    message: ChatMessage,
    isLastAssistant: Boolean,
    onCopy: () -> Unit,
    onRetry: () -> Unit
) {
    val isUser = message.role == ChatMessage.ROLE_USER
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (isUser) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.horizontalGradient(listOf(RoseColors.NeonBlue, RoseColors.Purple)))
                    .padding(12.dp)
            ) {
                Text(message.text, color = Color.White)
            }
        } else {
            GlassCard { Text(message.text, color = RoseColors.TextPrimary) }
        }
        Row {
            TextButton(onClick = onCopy) { Text("COPY", color = RoseColors.TextSecondary, fontSize = 11.sp) }
            if (!isUser && isLastAssistant) {
                TextButton(onClick = onRetry) { Text("RETRY", color = RoseColors.Cyan, fontSize = 11.sp) }
            }
        }
    }
}

fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("ROSE AI", text))
    Toast.makeText(context, "কপি হয়েছে", Toast.LENGTH_SHORT).show()
}
