package com.roseai.app.ui.theme

import androidx.compose.ui.graphics.Color

object RoseColors {
    val Background = Color(0xFF05060F)
    val Surface = Color(0xFF0C0F24)
    val NeonBlue = Color(0xFF00B4FF)
    val Cyan = Color(0xFF00F0FF)
    val Purple = Color(0xFF8A2BFF)
    val Pink = Color(0xFFFF2E9A)
    val TextPrimary = Color(0xFFEAF6FF)
    val TextSecondary = Color(0xFF9FB3D1)
    val Success = Color(0xFF3DFFA2)
    val Error = Color(0xFFFF4D6D)
}
