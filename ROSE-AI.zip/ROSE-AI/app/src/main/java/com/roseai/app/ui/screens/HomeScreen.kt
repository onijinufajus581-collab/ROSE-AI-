package com.roseai.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.roseai.app.R
import com.roseai.app.ui.components.AICharacter
import com.roseai.app.ui.components.AnimatedButton
import com.roseai.app.ui.components.FloatingParticles
import com.roseai.app.ui.components.GlassCard
import com.roseai.app.ui.theme.RoseColors
import com.roseai.app.viewmodel.RoseViewModel

@Composable
fun HomeScreen(
    vm: RoseViewModel,
    onChat: () -> Unit,
    onVoice: () -> Unit,
    onNewChat: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit,
    onApi: () -> Unit
) {
    val connection by vm.connectionLabel.collectAsState()
    val status by vm.status.collectAsState()
    val animations by vm.animationsEnabled.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(RoseColors.Background, Color(0xFF14082A), RoseColors.Background))
            )
    ) {
        FloatingParticles(enabled = animations)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.ic_launcher_foreground),
                    contentDescription = "ROSE AI logo",
                    modifier = Modifier.size(52.dp)
                )
                Text(
                    "  ROSE AI",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = RoseColors.Cyan
                )
            }

            AICharacter()

            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    "হ্যালো স্যার, আই এম রোজ এআই। আপনাকে কী সাহায্য করতে পারি?",
                    fontSize = 17.sp,
                    color = RoseColors.TextPrimary
                )
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("API STATUS", color = RoseColors.TextSecondary, fontSize = 12.sp)
                Text(connection, color = RoseColors.Success, fontWeight = FontWeight.SemiBold)
            }

            status?.let { message ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(message, color = RoseColors.Pink)
                }
            }

            AnimatedButton("💬  TEXT CHAT", Modifier.fillMaxWidth(), onClick = onChat)
            AnimatedButton("🎙  VOICE MODE", Modifier.fillMaxWidth(), onClick = onVoice)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedButton("NEW CHAT", Modifier.weight(1f), onClick = onNewChat)
                AnimatedButton("CHAT HISTORY", Modifier.weight(1f), onClick = onHistory)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedButton("🔑  API", Modifier.weight(1f), onClick = onApi)
                AnimatedButton("⚙  SETTINGS", Modifier.weight(1f), onClick = onSettings)
            }
        }
    }
}
