package com.roseai.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.roseai.app.ui.theme.RoseColors

/**
 * Animated AI companion character (stylized vector). It breathes and blinks.
 * Replace the drawing with your anime character artwork when it is ready.
 */
@Composable
fun AICharacter(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "character")
    val breathe by transition.animateFloat(
        0.98f, 1.03f,
        infiniteRepeatable(tween(2200), RepeatMode.Reverse),
        label = "breathe"
    )
    val eyeOpen by transition.animateFloat(
        1f, 0.1f,
        infiniteRepeatable(
            keyframes {
                durationMillis = 4000
                1f at 0
                1f at 3600
                0.1f at 3700
                1f at 3800
            }
        ),
        label = "blink"
    )
    Canvas(modifier.size(200.dp).graphicsLayer { scaleX = breathe; scaleY = breathe }) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension * 0.28f
        drawCircle(RoseColors.Purple.copy(alpha = 0.35f), radius = r * 1.4f, center = c)
        drawCircle(RoseColors.Cyan.copy(alpha = 0.15f), radius = r * 1.8f, center = c)
        drawCircle(Color(0xFF3A1F6B), radius = r * 1.25f, center = Offset(c.x, c.y - r * 0.1f))
        drawCircle(Color(0xFFFFE4D6), radius = r, center = c)
        drawArc(
            color = Color(0xFF2B1B5C),
            startAngle = 180f, sweepAngle = 180f, useCenter = true,
            topLeft = Offset(c.x - r * 1.05f, c.y - r * 1.05f),
            size = Size(r * 2.1f, r * 2.1f)
        )
        val eyeH = r * 0.28f * eyeOpen
        for (side in listOf(-1f, 1f)) {
            drawOval(
                color = Color(0xFF1B2A4A),
                topLeft = Offset(c.x + side * r * 0.38f - r * 0.12f, c.y + r * 0.05f - eyeH / 2),
                size = Size(r * 0.24f, eyeH)
            )
        }
        drawCircle(RoseColors.Pink.copy(alpha = 0.35f), radius = r * 0.14f, center = Offset(c.x - r * 0.6f, c.y + r * 0.3f))
        drawCircle(RoseColors.Pink.copy(alpha = 0.35f), radius = r * 0.14f, center = Offset(c.x + r * 0.6f, c.y + r * 0.3f))
        drawArc(
            color = Color(0xFFD9466F),
            startAngle = 20f, sweepAngle = 140f, useCenter = false,
            topLeft = Offset(c.x - r * 0.18f, c.y + r * 0.35f),
            size = Size(r * 0.36f, r * 0.2f),
            style = Stroke(width = 3f)
        )
    }
}
