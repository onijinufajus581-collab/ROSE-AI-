package com.roseai.app.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.roseai.app.data.ApiConfig
import com.roseai.app.data.Provider

/**
 * API credentials live in Android Keystore-backed encrypted preferences.
 * Keys are never hardcoded and never logged.
 */
class SecureStorage(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "rose_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun config(provider: Provider): ApiConfig = ApiConfig(
        provider = provider,
        apiKey = prefs.getString("key_${provider.name}", "") ?: "",
        model = prefs.getString("model_${provider.name}", null) ?: provider.defaultModel,
        baseUrl = prefs.getString("url_${provider.name}", null) ?: provider.defaultBaseUrl
    )

    fun activeProvider(): Provider? =
        prefs.getString("active", null)?.let { name -> Provider.values().firstOrNull { it.name == name } }

    fun activeConfig(): ApiConfig? =
        activeProvider()?.let { config(it) }?.takeIf { it.isUsable }

    /** Saves the config and makes its provider active. Call only after a successful test. */
    fun save(cfg: ApiConfig) {
        prefs.edit()
            .putString("key_${cfg.provider.name}", cfg.apiKey)
            .putString("model_${cfg.provider.name}", cfg.model)
            .putString("url_${cfg.provider.name}", cfg.baseUrl)
            .putString("active", cfg.provider.name)
            .apply()
    }

    fun clear(provider: Provider) {
        val editor = prefs.edit()
            .remove("key_${provider.name}")
            .remove("model_${provider.name}")
            .remove("url_${provider.name}")
        if (activeProvider() == provider) editor.remove("active")
        editor.apply()
    }
}
