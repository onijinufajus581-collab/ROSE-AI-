# Backend

Reserved for a future backend service. The current Android app calls AI providers directly
using the API key stored on the device, so nothing in this folder is required to build or run it.
